export function fixNull(input, fill = "") {
    if (!input) {
        return fill;
    }
    else {
        return input;
    }
}