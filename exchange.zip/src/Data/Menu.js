export const menuRows = [
	{
		id: 1,
		name: "راهنمای خدمات",
		body: "متن تست",
	},
	{
		id: 2,
		name: "طرح ها",
		body: "متن تست",
	},
];
