export const accessRows = [
	{
		id: 1,
		managerUsername: "TestAccount1",
		departemantId: 1,
		managerAccess: 0,
	},
	{
		id: 2,
		managerUsername: "TestAccount2",
		departemantId: 2,
		managerAccess: 1,
	},
];