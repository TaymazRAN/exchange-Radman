import "./message.css";

export default function Message() {
  return (
    <div>Message</div>
  )
}
