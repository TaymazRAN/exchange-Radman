import "./exercise.css";

export default function Exercise() {
  return (
    <div>Exercise</div>
  )
}
