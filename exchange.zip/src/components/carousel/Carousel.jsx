import "./carousel.css";

function Carousel() {
  return (
    <div className="carousel">
      <div className="carouselPicture"></div>
    </div>
  )
}

export default Carousel;
